Hi, this little tool will take any writing no matter how long and seperate it into pages for the other tool.

Just write whatever you want (or copy and paste stuff) into the journal.txt and save it, then run the prepper tool and it will generate a file where everything is formatted for the input.txt of the JournalMaker tool. 

:D